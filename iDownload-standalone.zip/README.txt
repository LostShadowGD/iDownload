Thanks for using iDownload!

Make sure to install get_iplayer, if you haven't already!
https://github.com/get-iplayer/get_iplayer_win32/releases/latest

YouTube downloads install here, "AppData\Local\iDownload", and this is added as a shortcut to the desktop.

---FAQ---

Q: Why do I get a huge amount of errors then the console closes when downloading BBC shows?
A: Confirm that the episode is available on the iPlayer currently.

Q: How do I make YouTube download somewhere else?
A: This is open source software. Figure out how to change it and recompile. It works for now.

Q: What quality does this download in?
A: For YouTube, the best quality it can while staying as an MP4. This is usually 1080p. Any higher (2K, 4K, 8K, etc) will download in DASH. I may add a converter to allow videos of this quality. For iPlayer, 1080p with 48kHz/~120kbps audio.

Q: Can I change the download quality?
A: Probably in the future, yes. For now, use a conversion software/video editor.